import React from 'react'
import ReactDOM from 'react-dom'
import Grid from '@material-ui/core/Grid';

const products = {
  "products": [
  {
    "id": 1,
    "name": "Brocolli",
    "price": 120,
    "image": "https://res.cloudinary.com/sivadass/image/upload/v1493620046/dummy-products/broccoli.jpg",
    "category": "vegetables",
    "description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
  },
  {
    "id": 2,
    "name": "Cauliflower",
    "price": 60,
    "image": "https://res.cloudinary.com/sivadass/image/upload/v1493620046/dummy-products/cauliflower.jpg",
    "category": "vegetables",
    "description": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
  },
]
}

function App(){
    return (<div>
      <Grid container spacing={1}>
        { 
          products.products.map((item) => {
            return <Grid container item xs={4} spacing={3}>{item.name}</Grid>
          })
        }
      </Grid>
    </div>)
}

ReactDOM.render(<App />, document.getElementById('root'))
